<footer>
    <div class="first">
        <img src="./assets/img/logo-white.png" alt="Logo">
        <p>2025 © All Rights reserved by Unaiza City Karachi</p>
        <a href="" class="privacy">Privacy Policy</a>
    </div>
    <div class="second">
        <h3>Follow us on</h3>
        <div class="social">
            <a href="https://www.facebook.com/profile.php?id=100087069331886" target="_blank">
                <i class="fab fa-facebook-f"></i>
            </a>

            <!-- Instagram Icon -->
            <a href="https://www.instagram.com/unaizacitykarachi/" target="_blank">
                <i class="fab fa-instagram"></i>
            </a>

            <!-- YouTube Icon -->
            <a href="https://wa.me/+923055999749" target="_blank">
                <i class="fab fa-whatsapp"></i>
            </a>
        </div>
    </div>
    <div class="third">
        <a class="active" href="../">Home</a>
        <a href="./about-us.php">
            About Us
        </a> 
        <a href="./uraisha-radiance.php">
            Projects
        </a> 
        <a href="./uraisha-radiance.php">
            Uraisha Radiance
        </a>
        <a href="./contact-us.php">
            Contact Us
        </a>
    </div>
</footer>